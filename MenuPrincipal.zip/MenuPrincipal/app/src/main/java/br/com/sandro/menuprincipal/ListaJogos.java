package br.com.sandro.menuprincipal;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Created by Aws on 28/01/2018.
 */

public class ListaJogos extends RecyclerView.Adapter<ListaJogos.MyViewHolder> {

    private Context mContext;
    private List<Jogos> mData;


    public ListaJogos(Context mContext, List<Jogos> mData) {
        this.mContext = mContext;
        this.mData = mData;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view;
        LayoutInflater mInflater = LayoutInflater.from(mContext);
        view = mInflater.inflate(R.layout.lista_jogos, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {

        holder.tv_book_title.setText(mData.get(position).getTitulo());
        holder.tv_book_developer.setText(mData.get(position).getDesenvolvedora());
        holder.tv_book_genre.setText(mData.get(position).getGenero());
        holder.img_book_thumbnail.setImageResource(mData.get(position).getImagemPequena());
        holder.img_book_thumbnail2.setImageResource(mData.get(position).getImagemGrande());
        holder.rb_rating.setRating(mData.get(position).getAvaliacao());
        holder.jogoFavorito.setImageResource(mData.get(position).getJogoFavorito());
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(mContext, JogosActivity.class);

                // passing data to the book activity
                intent.putExtra("Title", mData.get(position).getTitulo());
                intent.putExtra("Description", mData.get(position).getDescricao());
                intent.putExtra("Thumbnail", mData.get(position).getImagemPequena());
                intent.putExtra("Thumbnail2", mData.get(position).getImagemGrande());
                intent.putExtra("Developer", mData.get(position).getDesenvolvedora());
                intent.putExtra("Genre", mData.get(position).getGenero());
                intent.putExtra("Rating", mData.get(position).getAvaliacao());
                intent.putExtra("JogoFavorito", mData.get(position).getJogoFavorito());
                // start the activity
                mContext.startActivity(intent);

            }
        });


    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tv_book_title;
        TextView tv_book_developer;
        TextView tv_book_genre;
        RatingBar rb_rating;
        ImageView img_book_thumbnail, img_book_thumbnail2;
        CardView cardView;
        ImageView jogoFavorito;

        public MyViewHolder(View itemView) {
            super(itemView);

            tv_book_title = (TextView) itemView.findViewById(R.id.book_title_id);
            tv_book_developer = (TextView) itemView.findViewById(R.id.book_txt_dev);
            tv_book_genre = (TextView) itemView.findViewById(R.id.book_genero);
            img_book_thumbnail = (ImageView) itemView.findViewById(R.id.book_img_id);
            img_book_thumbnail2 = (ImageView) itemView.findViewById(R.id.book_img_id2);
            rb_rating = (RatingBar) itemView.findViewById(R.id.book_rating);
            jogoFavorito = (ImageView) itemView.findViewById(R.id.fav_icon);
            cardView = (CardView) itemView.findViewById(R.id.cardview_id);


        }
    }


}
